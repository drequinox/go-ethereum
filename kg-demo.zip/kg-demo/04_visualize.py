"""
04_visualize.py — Turn the unified knowledge graph into one self-contained
interactive HTML file (D3 force-directed). No server, no build step.

The headline demo feature: an "Explore from address" box — enter any node
(e.g. 0xALICE) and a hop depth, and the explorer highlights everything that
address relates to within N hops, across ALL relationship types. That is the
question a knowledge graph exists to answer.

Also: drag nodes, click to inspect (with LLM evidence spans where present),
filter by node type, zoom/pan.

Run:  python 04_visualize.py   ->   output/kg_explorer.html
"""

import json

g = json.load(open("output/unified_kg.json"))

for l in g["links"]:
    rel = l.get("rel", "")
    if rel == "TRANSFERRED" and l.get("usd"):
        l["display"] = f"{l.get('asset','')} ${float(l['usd']):,.0f}"
    else:
        l["display"] = rel

PAYLOAD = json.dumps(g)

HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Knowledge Graph Explorer</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
<style>
  :root{
    --bg:#101418; --panel:#171c22; --line:#252c35; --ink:#e8edf2;
    --muted:#8a95a3; --accent:#4cc2ff;
  }
  *{box-sizing:border-box} html,body{margin:0;height:100%}
  body{background:var(--bg);color:var(--ink);
       font:14px/1.5 ui-monospace,'SF Mono',Menlo,monospace;overflow:hidden}
  #wrap{display:flex;height:100vh}
  #graph{flex:1;position:relative}
  aside{width:310px;background:var(--panel);border-left:1px solid var(--line);
        padding:18px;overflow-y:auto}
  h1{font-size:15px;letter-spacing:.04em;margin:0 0 4px}
  .sub{color:var(--muted);font-size:12px;margin:0 0 16px}
  h2{font-size:11px;text-transform:uppercase;letter-spacing:.1em;
     color:var(--muted);margin:18px 0 8px;font-weight:600}
  input[type=text]{width:100%;background:var(--bg);color:var(--ink);
     border:1px solid var(--line);border-radius:6px;padding:8px 10px;
     font:inherit;font-size:12px;margin-bottom:8px}
  input[type=text]:focus{outline:none;border-color:var(--accent)}
  .row{display:flex;align-items:center;gap:10px;margin-bottom:8px;font-size:12px}
  input[type=range]{flex:1}
  button{background:var(--line);color:var(--ink);border:1px solid #313a45;
         border-radius:6px;padding:8px 12px;cursor:pointer;font:inherit;
         font-size:12px;width:100%;margin-bottom:8px}
  button:hover{border-color:var(--accent)}
  .chip{display:inline-flex;align-items:center;gap:6px;padding:4px 9px;
        margin:0 6px 6px 0;border:1px solid var(--line);border-radius:20px;
        cursor:pointer;font-size:11px;user-select:none}
  .chip.off{opacity:.32}
  .dot{width:9px;height:9px;border-radius:50%}
  #detail{font-size:12px;line-height:1.6}
  #detail .k{color:var(--muted)} #detail .v{word-break:break-word}
  #detail .ev{color:#e3b341;font-style:italic;border-left:2px solid var(--line);
              padding-left:8px;margin-top:6px;display:block}
  #hint{color:var(--muted);font-size:11px;margin-top:6px}
  .node circle{cursor:pointer;stroke:#101418;stroke-width:1.5px}
  .node circle.focus{stroke:var(--accent);stroke-width:3px}
  .node text{fill:var(--ink);font-size:10px;pointer-events:none;
             paint-order:stroke;stroke:#101418;stroke-width:3px}
  .link{stroke:#313a45;stroke-width:1.2px}
  .link.hot{stroke:var(--accent);stroke-width:2.2px}
  .linklabel{fill:var(--muted);font-size:8px;pointer-events:none}
  .faded{opacity:.10} .arrow{fill:#313a45}
</style></head>
<body><div id="wrap">
  <div id="graph"></div>
  <aside>
    <h1>KG EXPLORER</h1>
    <p class="sub">One graph from three sources: transfer ledger (CSV) +
       entity directory (JSON) + community notes (LLM-extracted prose)</p>
    <h2>Explore from address</h2>
    <input id="addr" type="text" placeholder="e.g. 0xALICE, Carol, AquaSwap"
           list="nodelist"><datalist id="nodelist"></datalist>
    <div class="row"><span>hops</span>
      <input id="hops" type="range" min="1" max="4" value="2">
      <span id="hopsval">2</span></div>
    <button id="exploreBtn">Show neighbourhood</button>
    <button id="resetBtn">Reset view</button>
    <h2>Filter by type</h2>
    <div id="filters"></div>
    <h2>Selection</h2>
    <div id="detail"><span class="k">Click a node, or explore from an
      address above.</span>
      <div id="hint">"Show neighbourhood" answers: given this address, what
      does it relate to on the network — across transfers, ownership,
      control, grants, memberships?</div></div>
  </aside>
</div>
<script>
const DATA = __PAYLOAD__;
const PALETTE=['#3fb950','#4cc2ff','#ff7eb6','#e3b341','#bc8cff','#ff9966',
               '#79e0d0','#f0883e'];
const types=[...new Set(DATA.nodes.map(n=>n.type))];
const COLOR={}; types.forEach((t,i)=>COLOR[t]=PALETTE[i%PALETTE.length]);
const active=new Set(types);

const W=()=>document.getElementById('graph').clientWidth;
const H=()=>document.getElementById('graph').clientHeight;
const svg=d3.select('#graph').append('svg').attr('width','100%').attr('height','100%');
svg.append('defs').append('marker').attr('id','arrow').attr('viewBox','0 -5 10 10')
  .attr('refX',22).attr('refY',0).attr('markerWidth',6).attr('markerHeight',6)
  .attr('orient','auto').append('path').attr('class','arrow').attr('d','M0,-5L10,0L0,5');
const root=svg.append('g');
svg.call(d3.zoom().scaleExtent([0.2,4]).on('zoom',e=>root.attr('transform',e.transform)));

const links=DATA.links.map(d=>Object.assign({},d));
const nodes=DATA.nodes.map(d=>Object.assign({},d));
const adj={}; nodes.forEach(n=>adj[n.id]=new Set());
links.forEach(l=>{adj[l.source].add(l.target);adj[l.target].add(l.source);});

// populate datalist for the address box
const dl=document.getElementById('nodelist');
nodes.forEach(n=>{const o=document.createElement('option');o.value=n.id;dl.appendChild(o);});

const sim=d3.forceSimulation(nodes)
  .force('link',d3.forceLink(links).id(d=>d.id).distance(95))
  .force('charge',d3.forceManyBody().strength(-360))
  .force('center',d3.forceCenter(W()/2,H()/2))
  .force('collide',d3.forceCollide(26));

const link=root.append('g').selectAll('line').data(links).join('line')
  .attr('class','link').attr('marker-end','url(#arrow)');
const llabel=root.append('g').selectAll('text').data(links).join('text')
  .attr('class','linklabel').attr('text-anchor','middle').text(d=>d.display||'');
const node=root.append('g').selectAll('g').data(nodes).join('g').attr('class','node')
  .call(d3.drag()
    .on('start',(e,d)=>{if(!e.active)sim.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y;})
    .on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y;})
    .on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null;}));
node.append('circle').attr('r',d=>d.type==='Wallet'?10:13)
  .attr('fill',d=>COLOR[d.type]||'#888');
node.append('text').attr('x',16).attr('y',4).text(d=>d.label||d.id);
node.on('click',(e,d)=>{inspect(d);neighbourhood(d.id,1);e.stopPropagation();});
svg.on('click',()=>reset(false));

sim.on('tick',()=>{
  link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y)
      .attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
  llabel.attr('x',d=>(d.source.x+d.target.x)/2).attr('y',d=>(d.source.y+d.target.y)/2);
  node.attr('transform',d=>`translate(${d.x},${d.y})`);
});

function inspect(d){
  const det=document.getElementById('detail');
  let h=`<div><span class="k">type </span><span class="v">${d.type}</span></div>
         <div><span class="k">id </span><span class="v">${d.id}</span></div>`;
  for(const[k,v]of Object.entries(d)){
    if(['id','type','label','x','y','vx','vy','fx','fy','index','evidence'].includes(k))continue;
    if(v===null||v===''||v===undefined)continue;
    h+=`<div><span class="k">${k} </span><span class="v">${v}</span></div>`;}
  if(d.evidence)h+=`<span class="ev">&ldquo;${d.evidence}&rdquo;</span>`;
  if(d.source==='llm')h+=`<div style="margin-top:8px;color:#e3b341">
    &#9889; extracted by LLM from unstructured text</div>`;
  det.innerHTML=h;
}

// BFS over ALL relationship types — the heart of the demo
function neighbourhood(start,depth){
  if(!(start in adj))return;
  const dist={[start]:0},q=[start];
  while(q.length){
    const c=q.shift();
    if(dist[c]>=depth)continue;
    for(const nx of adj[c])if(!(nx in dist)){dist[nx]=dist[c]+1;q.push(nx);}
  }
  node.classed('faded',n=>!(n.id in dist));
  node.select('circle').classed('focus',n=>n.id===start);
  link.classed('faded',l=>!(l.source.id in dist&&l.target.id in dist))
      .classed('hot',l=>l.source.id===start||l.target.id===start);
  llabel.classed('faded',l=>!(l.source.id in dist&&l.target.id in dist));
}

function reset(clearDetail=true){
  node.classed('faded',false);node.select('circle').classed('focus',false);
  link.classed('faded hot',false);llabel.classed('faded',false);
  if(clearDetail)document.getElementById('detail').innerHTML=
    '<span class="k">Click a node, or explore from an address above.</span>';
}

document.getElementById('hops').oninput=function(){
  document.getElementById('hopsval').textContent=this.value;};
document.getElementById('exploreBtn').onclick=()=>{
  const v=document.getElementById('addr').value.trim();
  const hit=nodes.find(n=>n.id===v)||
            nodes.find(n=>n.id.toLowerCase()===v.toLowerCase())||
            nodes.find(n=>(n.label||'').toLowerCase()===v.toLowerCase());
  if(!hit){document.getElementById('detail').innerHTML=
    `<span class="k">No node matches "${v}".</span>`;return;}
  inspect(hit);
  neighbourhood(hit.id,+document.getElementById('hops').value);
};
document.getElementById('addr').addEventListener('keydown',e=>{
  if(e.key==='Enter')document.getElementById('exploreBtn').click();});
document.getElementById('resetBtn').onclick=()=>{reset();sim.alpha(.5).restart();};

// type filters
const fbox=d3.select('#filters');
types.forEach(t=>{
  const c=fbox.append('div').attr('class','chip')
    .on('click',function(){
      active.has(t)?active.delete(t):active.add(t);
      d3.select(this).classed('off',!active.has(t));applyFilter();});
  c.append('span').attr('class','dot').style('background',COLOR[t]);
  c.append('span').text(t);
});
function applyFilter(){
  node.style('display',d=>active.has(d.type)?null:'none');
  link.style('display',l=>active.has(l.source.type)&&active.has(l.target.type)?null:'none');
  llabel.style('display',l=>active.has(l.source.type)&&active.has(l.target.type)?null:'none');
}
window.addEventListener('resize',()=>sim.force('center',d3.forceCenter(W()/2,H()/2)).alpha(.3).restart());
</script></body></html>"""

out = HTML.replace("__PAYLOAD__", PAYLOAD)
with open("output/kg_explorer.html", "w") as f:
    f.write(out)
print(f"Wrote output/kg_explorer.html ({len(out)//1024} KB) — open in a browser,")
print("type 0xALICE in the box, set hops, click 'Show neighbourhood'.")
